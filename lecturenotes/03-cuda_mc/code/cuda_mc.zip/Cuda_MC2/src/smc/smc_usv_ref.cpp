/*
 * smc_usv_ref.cpp
 *
 *  Created on: 09-Jul-2009
 *      Author: alee
 */

#include "func.h"
#include "usv.h"

#define TYPE usv

#define LIKELIHOOD_H usv_pdfh

#include "smc_ref.cpp"
