/*
 * smc_lg_ref.cpp
 *
 *  Created on: 08-Apr-2009
 *      Author: alee
 */

#include "func.h"
#include "gauss.h"

#define TYPE lg

#define LIKELIHOOD_H gauss1_mean_pdfh

#include "smc_ref.cpp"
