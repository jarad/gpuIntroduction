/*
 * smcs_gauss_gauss_ref.cpp
 *
 *  Created on: 08-Apr-2009
 *      Author: alee
 */

#include "func.h"
#include "gauss.h"

#define TYPE gg_mv

//#define TARGET1_H gauss_pdfh
#define LOG_TARGET1_H log_gauss_pdfh
//#define TARGET2_H gauss_pdfh
#define LOG_TARGET2_H log_gauss_pdfh

#include "smcs_ref_mv.cpp"
