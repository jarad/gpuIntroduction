/*
 * scan.cpp
 *
 *  Created on: 09-Apr-2009
 *      Author: alee
 */

#include "scan.h"

//void scan_ref(int N, float *h_idata, float* h_odata) {
//    double sum = 0;
//    for (int i = 0; i < N; i++) {
//        sum += h_idata[i];
//        h_odata[i] = (float) sum;
//    }
//}
