/*
 * order.h
 *
 *  Created on: 25-Mar-2009
 *      Author: alee
 */

#ifndef ORDER_H_
#define ORDER_H_

void maximum(int size, float *d_idata, float& h_odata, int nb, int nt);

void minimum(int size, float *d_idata, float& h_odata, int nb, int nt);


#endif /* ORDER_H_ */
