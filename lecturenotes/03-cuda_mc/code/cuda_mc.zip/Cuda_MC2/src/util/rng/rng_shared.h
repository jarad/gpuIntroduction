/*
 * rng_shared.h
 *
 *  Created on: 23-Mar-2009
 *      Author: alee
 */

#ifndef RNG_SHARED_H_
#define RNG_SHARED_H_

void BoxMuller_REF(float& u1, float& u2);

#endif /* RNG_SHARED_H_ */
