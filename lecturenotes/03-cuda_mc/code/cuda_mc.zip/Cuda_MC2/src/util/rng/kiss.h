/*
 * kiss.h
 *
 *  Created on: 04-Mar-2009
 *      Author: alee
 */

#ifndef KISS_H_
#define KISS_H_

unsigned int KISS();

void KISS_burn(int N);

void KISS_reset();

#endif /* KISS_H_ */
