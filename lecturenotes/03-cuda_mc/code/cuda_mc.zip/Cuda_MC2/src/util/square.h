/*
 * square.h
 *
 *  Created on: 19-Jan-2009
 *      Author: alee
 */

#ifndef SQUARE_H_
#define SQUARE_H_

void square(int size, float* d_data, int nb = 32, int nt = 128);

void square(int size, float* d_data, float* d_odata, int nb = 32, int nt = 128);

#endif /* SQUARE_H_ */
