#! /usr/bin/env python

from aksetup_helper import configure_frontend
configure_frontend()
